# Backend tamplete

## _Cyber4s_

This is a generic template for any backend project.

-   Using the M.V.C method.

## Features

-   we all starting any project with more or less the same lines of code.
-   This repo is gonna save us a few hours in total.
-   lets make it relevant and generic.
-   Its have a lot to improve, from English Grammer mistakes to Another Branch containing tamplate to a front project.
-   we have great power as we are 40 fullstack-developers, lets start to use it properly.
-   any one can add, even if its just an idea, write it down on "ideas for improve".

## Instructions for use

-   0.Hit the green "use this tamplate" button.
-   1."npm init -y".
-   2."npm i".
-   3."git init".
-   4.Add ".env" file , and write down your environment variables there.

## Instructions for improove this tamplate

-   0.open new branch, work there.
-   1.make the changes
-   2.keep it clear, and generic.
-   3.keep in extandable.
-   4.comment where nessery.
-   5.ask for marge.
-   6.if its working please remove from the ideas list.

## ideas for improve

| Feature                | Discription                      |
| ---------------------- | -------------------------------- |
| Expand CRUD oparations | add delete , and update examples |
| idia                   | Discription for this idea        |
| idia                   | Discription for this idea        |
| idia                   | Discription for this idea        |
| idia                   | Discription for this idea        |
| idia                   | Discription for this idea        |
| idia                   | Discription for this idea        |

## Contributors

-   Aviv Polak
-   Gavriel Frant
-   Ofer Klein

## License

Cyber4s
